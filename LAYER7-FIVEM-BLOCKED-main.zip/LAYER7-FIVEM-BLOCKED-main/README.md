# BLOQUEZ LE PLAYERS.JSON / BLOCK IT PLAYERS.JSON, DYNMANIC.JSON AND INFO.JSON

🇫🇷 : 
Les principales attaques sur fivem se font sur une attaque web donc layer7.

Mais il existe une ligne dans le server.cfg pour le totalement stop !

Attention si vous spammez avec l'URL /players.json avec un simple rafraîchissement de la page plusieurs fois votre IP sera bloquée de votre serveur pour une certaine temps.

A la première connexion dans l'URL /players.json vous aurez la liste des utilisateurs avec leur ping mais après un rafraîchissement vous aurez le message Nope.

Cette ligne n'est pas très connue sur les serveurs français car souvent les personnes qui ont cette commande veulent 💰 

J'ai donc décidé de partager sur mon github.

🇬🇧 : 
The main attacks on fivem are done on a web attack so layer7.

But there is a line in the server.cfg for the total stop!

This line is not well known on french servers because often people who have this command want to 💰 
Be careful if you spam with the URL /players.json with a simple refresh of the page several times your IP will be blocked from your server for a certain time.

At the first connection in the URL /players.json you will have the list of users with their ping but after a refresh you will have the message Nope

So I decided to share on my github.

```
set sv_requestParanoia 3

sv_endpointprivacy true

sv_forceIndirectListing true

sv_useDirectListing true

sv_authMinTrust 4
```


Vous avez la permission de copier mon texte à condition de donner crédit de mon github.


© Clashplayer 2021 - 2022
